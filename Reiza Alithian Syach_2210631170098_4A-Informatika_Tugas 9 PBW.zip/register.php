<?php
    session_start();
    if(isset($_SESSION["email"])){
        header("Location : perpus.php");
    }
    include_once("./connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>
    <form method="POST" action="./register_process.php">
        <label for="email">Email:</label><br>
        <input type="email" name="email" id="email"><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password"><br>

        <input type="submit" value="Register">
    </form>
    
</body>
</html>