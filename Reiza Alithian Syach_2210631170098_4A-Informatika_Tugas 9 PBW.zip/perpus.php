<?php
    session_start();
    
    if(!isset($_SESSION['email'])){
        header("Location: login.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Perpustakaan</title>
</head>
<body>
    <h4>Nama : Reiza Alithian Syach</h4>
    <h4>NPM : 2210631170098</h4>
    <h4>Kelas : 4A-Informatika</h4>
    <h4>Mata Kuliah : Pemrograman Web</h4>
    <h1>Aplikasi Perpustakaan</h1>

    <a href="./buku.php">Lihat Daftar Buku</a>
    <br>
    <a href="./staff.php">Lihat Daftar Staff</a>
    <br><br>
    <form action="logout_process.php"></form>



</body>
</html>